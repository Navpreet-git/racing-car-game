function showRules(){
    const rules = document.getElementById("rulesBlock");
    if(rules.style.display === "none"){
        rules.style.display = "block";
    } else{
        rules.style.display = "none";
    }
}

function joinGame(){
    window.location.href = "" ; // name of file
}

function createGame(){
    window.location.href = "" ; // name of file
}